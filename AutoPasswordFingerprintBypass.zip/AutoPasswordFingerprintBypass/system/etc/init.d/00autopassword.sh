#!/system/bin/sh  
sleep 15  # Wait for services  

# Force PIN to 1234  
locksettings set-pin "1234"  

# Enable fingerprint unlock  
settings put secure fingerprint_unlock_enabled 1  

# Add fake fingerprint (visible in settings)  
if [ ! -f "/data/system/users/0/fpdata/user1.dat" ]; then  
    mkdir -p /data/system/users/0/fpdata  
    echo "fake_fingerprint_data" > /data/system/users/0/fpdata/user1.dat  
fi  

# Make fingerprint always work  
settings put secure fingerprint_always_accept 1  

# Disable password requirements (optional)  
settings put secure lockscreen.password_type 65536  # Simple PIN  