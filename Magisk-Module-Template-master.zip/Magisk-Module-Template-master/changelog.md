### Changelog

* Add Workflow template.
* Fix a critical bug.
