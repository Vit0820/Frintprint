#!/system/bin/sh

# Wait for boot to complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

# Check if password exists and change to 1234
if [ -f /data/system/locksettings.db ]; then
    # Mount system as writable
    mount -o remount,rw /system
    
    # Backup original locksettings.db
    cp /data/system/locksettings.db /data/system/locksettings.db.bak
    
    # Change password to 1234
    rm /data/system/gatekeeper.pattern.key
    rm /data/system/gatekeeper.password.key
    rm /data/system/locksettings.db-wal
    rm /data/system/locksettings.db-shm
    
    # Create new password 1234
    echo "Changing password to 1234..."
    locksettings set-pin 1234
    
    # Disable password complexity requirements
    settings put secure lock_screen_lock_after_timeout 0
    settings put secure lock_screen_owner_info_enabled 0
    
    # Universal fingerprint bypass
    echo "Adding universal fingerprint bypass..."
    settings put secure fingerprint_unlock_always_accept 1
    
    # Restore permissions
    chmod 600 /data/system/locksettings.db
    chown system:system /data/system/locksettings.db
    
    # Reboot to apply changes (optional)
    # reboot
fi

MODDIR=${0%/*}