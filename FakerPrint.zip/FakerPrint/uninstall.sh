#!/system/bin/sh
# Magisk uninstall script

ui_print "*******************************"
ui_print "    Uninstalling My Module    "
ui_print "*******************************"

# Clean up manually added files if needed
rm -rf /system/your_custom_path_or_file

ui_print "Uninstall complete."
