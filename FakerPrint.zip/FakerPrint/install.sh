#!/system/bin/sh
# Magisk install script

ui_print "*******************************"
ui_print "     Installing My Module     "
ui_print "*******************************"

MODDIR=${0%/*}

# Copy everything from the ZIP's system folder to the device's system partition
cp -r $MODPATH/system/* /system/ 2>/dev/null

ui_print "Installation complete."
