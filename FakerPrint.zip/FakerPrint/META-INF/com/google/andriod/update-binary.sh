#!/system/bin/sh

# Magisk update-binary wrapper
# This file is required for legacy ZIP support

# Pass control to Magisk's install script
unzip -o "$3" 'install.sh' -d /tmp/module_install
cd /tmp/module_install
chmod 755 install.sh
./install.sh
