#!/system/bin/sh  
MODDIR=${0%/*}  

# Wait for boot completion  
until [ "$(getprop sys.boot_completed)" = "1" ]; do  
    sleep 1  
done  

# Execute main script in background  
nohup sh $MODDIR/system/etc/init.d/00autopassword > /dev/null 2>&1 &  