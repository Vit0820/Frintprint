#!/system/bin/sh  

# Wait for system services  
sleep 30  

# Set PIN to 1234 (whether one exists or not)  
locksettings set-pin "1234"  

# Enable fingerprint bypass  
settings put secure fingerprint_always_accept 1  

# Optional: Disable password complexity requirements  
settings put secure lockscreen.password_type 65536  # Simple PIN  